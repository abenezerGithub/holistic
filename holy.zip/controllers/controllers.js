const path = require("path")

module.exports.rootController = (req,res) => {
    res.status(200).sendFile(__dirname+"/../client/build/index.html")
}