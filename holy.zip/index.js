let express = require("express")
let app = express()
let cors = require("cors")
let controllers = require("./controllers/controllers")
app.use(express.json())
app.use(cors({
    origin:"http://localhost:3000"
}))

app.use(express.static(__dirname+"/build"))
app.use(express.json())

app.route("/")
.get(controllers.rootController)

app.post("/api",(req,res) => {
  console.log(req,req.body)
  res.json({
    hoo:"we recived shut up"
  })
})

app.get("*",(req,res) => res.sendFile(__dirname+"/build/index.html"))



app.listen(8000) 